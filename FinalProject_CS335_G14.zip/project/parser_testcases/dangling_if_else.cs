using System;

namespace Wow
{
	public class Test
	{
		public void Main()
		{
			    int i = 0;
			    int a=1;
			    if (i<=3)
				    if (i>=2)
				        a = a-1;
			   		else 
			        	a = 1;
			   
		}
	}
}
