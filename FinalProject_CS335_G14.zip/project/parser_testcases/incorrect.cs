// #include <stdio.h>
// int main(){
//     int i=6;
//     for (;i<= 8 && i 6.67 && i!= 7; i++){
// 	int 36a;
// 	int `$#@name;
//         if (i>=0);{
//             printf("yes\n");
//         }
//         else 
//             printf("no\n");
//     }
//     return 0;
// }

using System;

public class Test
{
    public void Main()
    {
        int i=6;
        bool yes;
        int `$#@name;
        for (;i<= 8 && i 6.67 && i!= 7; i++){
        int 36a;
        if (i>=0);{
                    yes=true;
        }
        else 
                    yes=false;
        }
    }
}