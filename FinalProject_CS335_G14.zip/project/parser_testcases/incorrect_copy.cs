using System;

public class Test
{
    public void Main()
    {
        int i=6;
        for(;i<=7 && i!=3 && i>=2; ++i){ 
            ;
        }
        int 0x123;
        float 1e2,1e2e3,1.2.3;
        if (i>=0);{
                    yes=true;
        }
        else 
                    yes=false;
        }
    }
}