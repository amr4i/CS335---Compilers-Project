using System;

public class Test
{
	public void Main()
	{
		int i=6;
		bool yes;
		for(;i<=8 && i>=6 && i!=7; i+=1){
			if(i>=0){
				yes=true;
			}
			else
				yes=false;
		}
	}
}