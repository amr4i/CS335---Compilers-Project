using System;
namespace Rextester
{
    public class Program
    {
        public void Main()
        {
            int[] c = new int[5]{10,2,31,4,5}; 
            c[1] = 409;
            int d;
            d = c[3];
            print(d);
            // if(c[1] > 20){
                // int m = 3;
            // }
            int k = 10;  
            print("i am a string");
            print(k);
            print(10);
        }
    }
}
