// Program to Find the Frequency of the Word ʺtheʺ in a given Sentence

using System;

namespace doubleClass{
    class first
        {
            public void Main()
            {
                int i=9;
                char[] sid=new char[3]{'S','i','\0'};
                char x='f';
                sid[0]=x;
            }
        }
    public class second
        {
            public int Count()
            {
                int i = 0;
                while(i<20){
                    ++i;
                }
                return i;
            }
        }
}
