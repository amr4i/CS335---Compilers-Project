//Program to Swap two Numbers

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RetardProgram
    {
        class Program
        {
            void Main(string[] args)
            {
                int i=10;
                int arr = new int[5]{1,2,3,4,5};
                print(i);
            }
        }
    }
