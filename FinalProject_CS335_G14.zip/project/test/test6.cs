using System;
namespace Rextester
{
    public class Program
    {
        public void Main(string[] args)
        {
		int a = 5;
		do {
			a = a + 1;
			if((a=0) != 1){
				int p = 6;
			}
		}
		while(a<=10);
		int b = a;
        }
    }
}
