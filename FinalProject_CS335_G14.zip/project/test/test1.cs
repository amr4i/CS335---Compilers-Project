// Program to Check whether the Entered Number is Even or Odd

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
   
namespace check1
{
    class Program
        {   
            void Main()
            {
                int i=9;
                int res;
                if(i<9){
                    
                }
                else if(i==9)
                    res=0;
                else 
                    res=1;
                
            }
        }
}
